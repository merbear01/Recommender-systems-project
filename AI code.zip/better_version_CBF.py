"""
Author: Sharma, Aditya
reference: Sharma, Aditya. “Python Recommender Systems: Content Based & Collaborative Filtering Recommendation Engines.”
Www.datacamp.com, May 2020, www.datacamp.com/tutorial/recommender-systems-python. Accessed 13 Dec. 2022.
dataset_used: Netflix Dataset Latest 2021
"""



import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)import seaborn as sns
import seaborn as sns
import matplotlib.pyplot as plt
import time

start_time = time.time()
netflix_overall=pd.read_csv("C:/Users/dell/Downloads/Netflix Dataset Latest(UTF-8 comma delimited).csv")
head1 = netflix_overall.head()
# print(head1)

""""""
overall_count = netflix_overall.count()
# print(overall_count)

""""""
netflix_shows=netflix_overall[netflix_overall['Series or Movie']=='Series']
# print(netflix_shows)

""""""
netflix_movies=netflix_overall[netflix_overall['Series or Movie']=='Movie']
# print(netflix_movies)
""""""
sns.set(style="darkgrid")
ax = sns.countplot(x="Series or Movie", data=netflix_overall, palette="Set2")
plt.show()

""""""


plt.figure(figsize=(12,10))
sns.set(style="darkgrid")
ax2 = sns.countplot(x="Hidden Gem Score", data=netflix_movies, palette="Set2", order=netflix_movies['Hidden Gem Score'].value_counts().index[0:15])
plt.show()


""""""
plt.figure(figsize=(12,10))
sns.set(style="darkgrid")
sns.countplot(x="View Rating", data=netflix_movies, palette="Set2", order=netflix_movies['View Rating'].value_counts().index[0:15])
plt.show()


"""The TF-IDF(Term Frequency-Inverse Document Frequency (TF-IDF) ) score is the frequency of a 
word occurring in a document, down-weighted by the number of documents in which it occurs. This 
is done to reduce the importance of words that occur frequently in plot overviews and therefore, 
their significance in computing the final similarity score."""
from sklearn.feature_extraction.text import TfidfVectorizer
#removing stopwords
tfidf = TfidfVectorizer(stop_words='english')

#Replace NaN with an empty string
netflix_overall['Summary'] = netflix_overall['Summary'].fillna('')

#Construct the required TF-IDF matrix by fitting and transforming the data
tfidf_matrix = tfidf.fit_transform(netflix_overall['Summary'])

#Output the shape of tfidf_matrix
# print(tfidf_matrix.shape)


"""Import linear_kernel"""
from sklearn.metrics.pairwise import linear_kernel

# Compute the cosine similarity matrix
cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
print(cosine_sim[1])
print(cosine_sim.shape)

indices = pd.Series(netflix_overall.index, index=netflix_overall['Title']).drop_duplicates()
def get_recommendations(title, cosine_sim=cosine_sim):
    idx = indices[title]

    # Get the pairwsie similarity scores of all movies with that movie
    sim_scores = list(enumerate(cosine_sim[idx]))

    # Sort the movies based on the similarity scores
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Get the scores of the 10 most similar movies
    sim_scores = sim_scores[1:11]

    # Get the movie indices
    movie_indices = [i[0] for i in sim_scores]

    # Return the top 10 most similar movies
    return netflix_overall['Title'].iloc[movie_indices]


recommend2 = get_recommendations('You Are My Sunshine')
print(recommend2)

end_time = time.time()

time_taken = end_time-start_time
print("time taken to run the code: ", time_taken)